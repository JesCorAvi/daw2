var sobremi = document.getElementById("sobremi");
sobremi.onclick = ()=> {location.replace("http://www.google.es")}
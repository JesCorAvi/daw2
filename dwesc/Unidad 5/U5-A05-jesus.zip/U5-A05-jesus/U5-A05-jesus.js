document.addEventListener("mousedown", ()=>{
    document.getElementById("imagen").style.backgroundImage  = "url('ñu.png')";
    }
)
document.addEventListener("mouseup", ()=>{
    document.getElementById("imagen").style.backgroundImage  = "url('ñu1.jpg')";
    }
)
